<template>
  <nav>
    <router-link to="/">Inicio</router-link> |
    <router-link to="/about">Acerca</router-link>
  </nav>
</template>

<script>
export default {
  name: 'Navbar'
}
</script>

<style scoped>
nav {
  padding: 1rem;
  background: #42b883;
}
a {
  color: white;
  margin: 0 5px;
  text-decoration: none;
}
a.router-link-exact-active {
  font-weight: bold;
  text-decoration: underline;
}
</style>
