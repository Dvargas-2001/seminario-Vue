<template>
  <div>
    <h1>Página de Inicio</h1>
    <input v-model="mensaje" placeholder="Escribe algo" />
    <p>Tu escribiste: {{ mensaje }}</p>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      mensaje: ''
    }
  }
}
</script>
