<template>
  <div>
    <h1>Página Acerca de</h1>
    <p>Este proyecto está hecho con Vue 3 + Vite 🚀</p>
  </div>
</template>

<script>
export default {
  name: 'About'
}
</script>
